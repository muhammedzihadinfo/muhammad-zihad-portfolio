# Muhammad Zihad — Personal Portfolio

A responsive personal portfolio built with React, TypeScript, and Vite. It includes About, Skills, Projects, Contact, a mobile navigation menu, and a dark/light theme toggle.

## Run locally

1. Install Node.js (LTS).
2. Open this project folder in a terminal.
3. Run:

   ```bash
   npm install
   npm run dev
   ```

4. Open the local URL printed by Vite.

## Personalize before publishing

Search `src/App.tsx` and update:

- `hello@example.com` to your real public contact email.
- The LinkedIn URL to your profile (or remove that icon if you do not use LinkedIn).
- The About section with your own bio.
- `skills` and `projects` with your real skills and completed projects.
- Replace placeholder project cards before presenting them as completed work.

## Enable the contact form with Supabase (optional)

The portfolio works without Supabase; the contact form will show a note to email you directly. To store messages:

1. Open your Supabase project and go to **SQL Editor**.
2. Run the contents of `supabase-schema.sql`.
3. Copy `.env.example` to `.env`.
4. Add your Supabase project URL and anon/publishable key to `.env`.
5. Restart the dev server.

Never put a Supabase service-role key in frontend environment variables. The SQL policy permits anonymous inserts only; it does not permit visitors to read messages.

## Deploy to Netlify

Import the GitHub repository in Netlify. Build command: `npm run build`. Publish directory: `dist`. These settings are also in `netlify.toml`.

If you enable Supabase, add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in Netlify site environment variables.

## GitHub upload

Upload the contents of this folder to the root of `muhammad-zihad-portfolio`. Do not upload `node_modules`, `dist`, or your private `.env` file.
