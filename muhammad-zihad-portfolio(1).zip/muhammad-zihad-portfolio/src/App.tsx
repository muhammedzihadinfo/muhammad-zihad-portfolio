import { useState } from 'react'
import { ArrowDown, ArrowRight, ArrowUpRight, Github, Linkedin, Mail, Menu, Moon, Sun, X, Code2, Cpu, Rocket, Send, Sparkles } from 'lucide-react'
import { supabase } from './supabase'

const skills = ['HTML & CSS', 'JavaScript', 'TypeScript', 'React', 'Python', 'Git & GitHub', 'Problem Solving', 'Learning in Public']
const projects = [
  { number: '01', title: 'Personal Portfolio', description: 'A responsive home on the web to introduce myself, share what I build, and make it easy to get in touch.', tags: ['React', 'TypeScript', 'CSS'], href: 'https://github.com/muhammedzihadinfo/muhammad-zihad-portfolio' },
  { number: '02', title: 'Project Two', description: 'Replace this card with a project you have built. Explain the problem, your approach, and what you learned.', tags: ['Your stack', 'Your skills'], href: 'https://github.com/muhammedzihadinfo' },
  { number: '03', title: 'Project Three', description: 'Your next great idea goes here. Add a live demo link and a repository link when it is ready.', tags: ['In progress', 'Experiment'], href: 'https://github.com/muhammedzihadinfo' },
]

export default function App() {
  const [dark, setDark] = useState(true)
  const [menuOpen, setMenuOpen] = useState(false)
  const [sending, setSending] = useState(false)
  const [status, setStatus] = useState('')
  const [form, setForm] = useState({ name: '', email: '', message: '' })

  async function submitMessage(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setStatus('')
    if (!supabase) { setStatus('Contact form is not connected yet. Please email me directly.'); return }
    setSending(true)
    const { error } = await supabase.from('messages').insert([form])
    setSending(false)
    if (error) setStatus('Sorry, your message could not be sent. Please email me directly.')
    else { setStatus('Thanks! Your message has been sent.'); setForm({ name: '', email: '', message: '' }) }
  }

  const closeMenu = () => setMenuOpen(false)
  return <div className={dark ? 'site dark' : 'site light'}>
    <header className="header"><a className="brand" href="#home" onClick={closeMenu}>MZ<span>.</span></a>
      <button className="mobile-toggle icon-btn" aria-label="Toggle navigation" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</button>
      <nav className={menuOpen ? 'nav open' : 'nav'}><a href="#about" onClick={closeMenu}>About</a><a href="#skills" onClick={closeMenu}>Skills</a><a href="#projects" onClick={closeMenu}>Projects</a><a href="#contact" onClick={closeMenu}>Contact</a><button className="theme-toggle icon-btn" aria-label="Toggle color theme" onClick={() => setDark(!dark)}>{dark ? <Sun /> : <Moon />}</button></nav>
    </header>
    <main>
      <section className="hero section" id="home"><div className="hero-copy"><div className="eyebrow"><span className="pulse" /> AVAILABLE FOR NEW IDEAS</div><p className="hello">Hey, I'm</p><h1>Muhammad<br/><span>Zihad.</span></h1><h2>Curious mind. <em>Builder</em> in progress.</h2><p className="hero-text">I’m passionate about technology, programming, and turning curious ideas into real things. This is where I share my journey and the things I build.</p><div className="hero-actions"><a className="btn primary" href="#projects">Explore my work <ArrowUpRight size={17}/></a><a className="text-link" href="#contact">Let's talk <ArrowRight size={16}/></a></div><div className="socials"><a href="https://github.com/muhammedzihadinfo" target="_blank" rel="noreferrer" aria-label="GitHub"><Github/></a><a href="https://www.linkedin.com/" target="_blank" rel="noreferrer" aria-label="LinkedIn"><Linkedin/></a><a href="mailto:hello@example.com" aria-label="Email"><Mail/></a></div></div><div className="hero-art" aria-label="Decorative technology illustration"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="orbit orbit-three"/><div className="core"><Code2 size={54}/></div><div className="float-card card-top"><Cpu size={18}/><span>Curiosity.exe</span><b>RUNNING</b></div><div className="float-card card-bottom"><Sparkles size={18}/><span>Ideas → Reality</span></div><div className="art-dot dot-one"/><div className="art-dot dot-two"/><div className="art-dot dot-three"/></div><a href="#about" className="scroll-hint"><span>SCROLL TO EXPLORE</span><ArrowDown size={15}/></a></section>
      <section className="section about" id="about"><div className="section-label">01 / ABOUT ME</div><div className="section-grid"><div><h2 className="section-title">A little curiosity<br/>goes a <span>long way.</span></h2></div><div className="about-copy"><p className="lead">I believe the best way to understand technology is to build with it.</p><p>I'm Muhammad Zihad, an aspiring developer who loves exploring how things work — from software and AI to robotics and the world of engineering. I'm on a journey to learn deeply, create useful projects, and keep getting better one step at a time.</p><p>This portfolio is a living record of that journey. More experiments, projects, and lessons are on the way.</p><div className="stats"><div><strong>∞</strong><span>Curiosity</span></div><div><strong>24/7</strong><span>Learning mindset</span></div><div><strong>01</strong><span>Step at a time</span></div></div></div></div></section>
      <section className="section skills" id="skills"><div className="section-label">02 / WHAT I WORK WITH</div><div className="skills-heading"><h2 className="section-title">Tools for making<br/><span>things happen.</span></h2><p>My toolkit is always evolving. Here are some technologies and skills I'm exploring and developing.</p></div><div className="skill-grid">{skills.map((skill, i) => <div className="skill" key={skill}><span className="skill-index">0{i + 1}</span><span>{skill}</span><ArrowUpRight size={16}/></div>)}</div></section>
      <section className="section projects" id="projects"><div className="section-label">03 / SELECTED WORK</div><div className="projects-heading"><h2 className="section-title">Ideas made<br/><span>real.</span></h2><p>A few things from my building journey. This collection will grow as I create more.</p></div><div className="project-list">{projects.map(project => <article className="project" key={project.number}><div className="project-number">{project.number}</div><div className="project-content"><h3>{project.title}</h3><p>{project.description}</p><div className="tags">{project.tags.map(tag => <span key={tag}>{tag}</span>)}</div></div><a className="project-link" href={project.href} target="_blank" rel="noreferrer" aria-label={`Open ${project.title}`}><ArrowUpRight/></a></article>)}</div></section>
      <section className="section contact" id="contact"><div className="section-label">04 / GET IN TOUCH</div><div className="contact-grid"><div><h2 className="section-title">Have an idea?<br/><span>Let's connect.</span></h2><p className="contact-intro">Have a question, an interesting project, or just want to say hello? My inbox is open.</p><a className="email-link" href="mailto:hello@example.com"><Mail size={18}/> hello@example.com <ArrowUpRight size={16}/></a></div><form className="contact-form" onSubmit={submitMessage}><label>Your name<input required value={form.name} onChange={e => setForm({...form, name:e.target.value})} placeholder="Jane Smith"/></label><label>Email address<input required type="email" value={form.email} onChange={e => setForm({...form, email:e.target.value})} placeholder="jane@example.com"/></label><label>Your message<textarea required rows={4} value={form.message} onChange={e => setForm({...form, message:e.target.value})} placeholder="Tell me what's on your mind..."/></label><button className="btn primary submit" disabled={sending}>{sending ? 'Sending...' : 'Send message'} <Send size={16}/></button>{status && <p className="form-status" role="status">{status}</p>}</form></div></section>
    </main>
    <footer className="footer"><a className="brand" href="#home">MZ<span>.</span></a><p>Designed with curiosity. Built with care.</p><span>© {new Date().getFullYear()} Muhammad Zihad</span></footer>
  </div>
}
